class Engine:

    def __init__(self, engineType) :
        self.engineType = engineType
    
    def startEngine(self):
        print("Engine is running")

    def stopEngine(self):
        print("Engine is off")